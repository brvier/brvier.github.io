import gtk
import gobject
import pango
import hildon

VERSION='1.3'

###############################################################################
# @brief About dialog
###############################################################################
class AboutDialog (gtk.Dialog):

  #############################################################################
  # @brief Initialize screen
  #############################################################################
  def __init__ (self):
    gtk.Dialog.__init__ (self,'About PySnippet', None, gtk.DIALOG_MODAL,
                        (gtk.STOCK_OK, gtk.RESPONSE_OK))
    self.set_position (gtk.WIN_POS_CENTER)
    self.set_size_request (480, 350)
    self.set_type_hint (gtk.gdk.WINDOW_TYPE_HINT_DIALOG)
    self.set_border_width (10)

    self.vbox.set_spacing (5)

    fonttitle = pango.FontDescription ("Arial 16")
    label = gtk.Label ('Pysnippet v%s' % VERSION)
    label.modify_font (fonttitle)
    label.show ()
    self.vbox.pack_start (label, False, False)

    label = gtk.Label ('by Eduardo Aguiar')
    font = pango.FontDescription ("Arial 12")
    label.modify_font (font)
    label.show ()
    self.vbox.pack_start (label, False, False)

    label = gtk.Label ('Ported to Maemo by Benoit HERVIER')
    font = pango.FontDescription ("Arial 12")
    label.modify_font (font)
    label.show ()
    self.vbox.pack_start (label, False, False)

    label = gtk.Label ('''PySnippet is a code snippet manager for any language.
It features an user defined folder hierarchy, syntax
highlighting, automatic clipboard copying and XML based
data file. It is written in Python/PyGTK.

PySnippet is licensed under GNU Public License (GPL).
See http://www.gnu.org/licenses/gpl.html for further
information.''')
    label.set_line_wrap (True)
    font = pango.FontDescription ("Arial 10")
    label.modify_font (font)
    label.show ()
    self.vbox.pack_end (label, False, False)
