import gtk
import keyword
import string
import snippet.tokenize as tokenize
import StringIO

###############################################################################
# @brief Highlight pygtk code
###############################################################################
class PyGTKSyntax:
  language = 'pygtk'
  description = 'Python w/GTK'

  #############################################################################
  # @brief Populate buffer with tags
  #############################################################################
  def populate_buffer (self, buffer):
    buffer.create_tag ("pygtk_keyword",  foreground="#0000ff")
    buffer.create_tag ("pygtk_string",   foreground="#004488")
    buffer.create_tag ("pygtk_comment",  foreground="#009900")
    buffer.create_tag ("pygtk_constant", foreground="#e07818")

  #############################################################################
  # @brief Parse code
  #############################################################################
  def scan (self, code):
    fp = StringIO.StringIO (code)
    state = 0
    chars = string.uppercase + '_'

    try:
      for type, text, (srow, scol), (erow, ecol), line in	\
          tokenize.generate_tokens (fp.readline):
        tag = None

        #######################################################################
        # Known tags
        #######################################################################
        if type == tokenize.NAME and keyword.iskeyword (text):
          tag = "pygtk_keyword"

        elif type == tokenize.STRING:
          tag = "pygtk_string"

        elif type == tokenize.COMMENT:
          tag = "pygtk_comment"

        #######################################################################
        # FSM for gtk and gtk.gdk constants
        #######################################################################
        if state == 0:
          if text == 'gtk':
            state = 1
            c_srow = srow
            c_scol = scol
          elif text == 'gobject':
            state = 3
            c_srow = srow
            c_scol = scol

        elif state == 1:
          if text == '.':
            state = 2
          else:
            state = 0

        elif state == 2:
          if text == 'gdk':
            state = 3
          elif False not in [c in chars for c in text]:
            tag = 'pygtk_constant'
            srow = c_srow
            scol = c_scol
            state = 0
          else:
            state = 0

        elif state == 3:
          if text == '.':
            state = 4
          else:
            state = 0

        elif state == 4:
          if False not in [c in chars for c in text]:
            tag = 'pygtk_constant'
            srow = c_srow
            scol = c_scol
          state = 0

        #######################################################################
        # Release tag, if any
        #######################################################################
        if tag:
          yield tag, (srow, scol), (erow, ecol)

    except tokenize.TokenError, e:
      pass
