###############################################################################
# @brief Highlight C code
###############################################################################
c_keywords = dict.fromkeys (
  ['auto', 'break', 'case', 'char', 'const', 'continue', 'default', 'do',
   'double', 'else', 'enum', 'extern', 'float', 'for', 'goto', 'if',
   'inline', 'int', 'long', 'register', 'restrict', 'return', 'short',
   'signed', 'sizeof', 'static', 'struct', 'switch', 'typedef', 'union',
   'unsigned', 'void', 'volatile', 'while'])

class CSyntax:
  language = 'c'
  description = 'C'

  #############################################################################
  # @brief Populate buffer with tags
  #############################################################################
  def populate_buffer (self, buffer):
    buffer.create_tag ("c_keyword", foreground="#0000ff")
    buffer.create_tag ("c_string",  foreground="#004488")
    buffer.create_tag ("c_char",    foreground="#004488")
    buffer.create_tag ("c_comment", foreground="#009900")
    buffer.create_tag ("c_error",   foreground="#FF0000")

  #############################################################################
  # @brief Do highlight
  #############################################################################
  def scan (self, code):
    scanner = CppScanner (code)

    for token, text, srow, scol, erow, ecol in scanner.scan ():
      tag = None

      if token in ('COMMENT', 'ERROR', 'CHAR', 'STRING'):
        tag = 'c_%s' % token.lower ()

      elif token == 'IDENTIFIER' and text in c_keywords:
        tag = 'c_keyword'
        
      if tag:
       yield tag, (srow, scol), (erow, ecol)

###############################################################################
# @brief Highlight C++ code
###############################################################################
cpp_keywords = dict.fromkeys (
  ['auto', 'break', 'case', 'char', 'const', 'continue', 'default', 'do',
   'double', 'else', 'enum', 'extern', 'float', 'for', 'goto', 'if',
   'inline', 'int', 'long', 'register', 'restrict', 'return', 'short',
   'signed', 'sizeof', 'static', 'struct', 'switch', 'typedef', 'union',
   'unsigned', 'void', 'volatile', 'while',
   'bool', 'export', 'true', 'false', 'template', 'class', 'new', 'delete',
   'private', 'protected', 'public', 'mutable', 'explicit', 'operator',
   'using', 'namespace', 'throw', 'catch', 'virtual'])

class CppSyntax:
  language = 'cpp'
  description = 'C++'

  #############################################################################
  # @brief Populate buffer with tags
  #############################################################################
  def populate_buffer (self, buffer):
    buffer.create_tag ("cpp_keyword", foreground="#0000ff")
    buffer.create_tag ("cpp_string",  foreground="#004488")
    buffer.create_tag ("cpp_char",    foreground="#004488")
    buffer.create_tag ("cpp_comment", foreground="#009900")
    buffer.create_tag ("cpp_error",   foreground="#FF0000")

  #############################################################################
  # @brief Do highlight
  #############################################################################
  def scan (self, code):
    scanner = CppScanner (code)

    for token, text, srow, scol, erow, ecol in scanner.scan ():
      tag = None

      if token in ('COMMENT', 'ERROR', 'CHAR', 'STRING'):
        tag = 'cpp_%s' % token.lower ()

      elif token == 'IDENTIFIER' and text in cpp_keywords:
        tag = 'cpp_keyword'
        
      if tag:
       yield tag, (srow, scol), (erow, ecol)


import string

###############################################################################
# @brief  Handle source codes
# @author Eduardo Aguiar
###############################################################################
class Source:

  def __init__ (self, data=''):
    self.data   = data
    self.pos    = 0
    self.row    = 1
    self.col    = 0
    self.length = len (self.data)

  #############################################################################
  # @brief Feed some data
  #############################################################################
  def feed (self, data):
    self.data += data
    self.length = len (self.data)

  #############################################################################
  # @brief Return data from current position
  #############################################################################
  def peek (self):
    return self.data[self.pos:]

  #############################################################################
  # @brief Return data from current position
  #############################################################################
  def eof (self):
    return self.pos >= self.length

  #############################################################################
  # @brief Skip n characters, counting line breaks
  #############################################################################
  def skip (self, siz):
    length = min (self.pos + siz, self.length)

    while self.pos < length:
      if self.data[self.pos] == '\n':
        self.row += 1
        self.col  = 0
        self.pos += 1
      elif self.data[self.pos:self.pos+1] == '\r\n':
        self.row += 1
        self.col  = 0
        self.pos += 2
      elif self.data[self.pos] == '\r':
        self.row += 1
        self.col  = 0
        self.pos += 1
      else:
        self.col += 1
        self.pos += 1

  #############################################################################
  # @brief  scan while chars are contained in 'str'
  # @param  str String containing valid characters
  # @return pos, text (pos == -1 if text was not found)
  #############################################################################
  def while_contains (self, str):
    data   = self.peek ()
    length = len (data)
    pos    = 0

    while pos < length and data[pos] in str:
      pos += 1

    self.skip (pos) 
    return pos, data[:pos]

  #############################################################################
  # @brief  scan while chars are not contained in 'str'
  # @param  str String containing valid characters
  # @return pos, text (pos == -1 if text was not found)
  #############################################################################
  def while_not_contains (self, str):
    data   = self.peek ()
    length = len (data)
    pos    = 0

    while pos < length and data[pos] not in str:
      pos += 1

    self.skip (pos) 
    return pos, data[:pos]

  #############################################################################
  # @brief scan until finds a substring
  # @param str substring
  # @return pos, text (pos == -1 if text was not found)
  #############################################################################
  def find (self, str):
    data = self.peek ()
    pos  = data.find (str)

    if pos == -1:
      siz = len (data)
    else:
      siz = pos + len (str)

    self.skip (siz)
    return pos, data[:siz]


###############################################################################
# @brief  Scanner for C/C++ files
# @author Eduardo Aguiar
###############################################################################
class CppScanner:

  def __init__ (self, data=''):
    self.data = data

  def feed (self, data):
    self.data += data

  def scan (self):
    source = Source (self.data)
    state  = 0    # headername FSM

    while not source.eof ():
      srow = source.row
      scol = source.col
      data = source.peek ()

      # COMMENT (C++)
      if data[:2] == '//':
        token = 'COMMENT'
        pos, text = source.while_not_contains ('\n')

      # COMMENT (C)
      elif data[:2] == '/*':
        pos, text = source.find ('*/')
        if pos == -1:
          token = 'ERROR'
        else:
          token = 'COMMENT'
   
      # SPACE
      elif data[0] in string.whitespace:
        token = 'SPACE'
        pos, text = source.while_contains (string.whitespace)

      # HEADERNAME
      elif state == 2 and data[0] in '"<':
        if data[0] == '<':
          pos, text = self.scan_until (source, '>')
        else:
          pos, text = self.scan_until (source, '"')

        if pos == -1:
          token = 'ERROR'
        else:
          token = 'HEADERNAME'

      # CHAR/LCHAR
      elif data[0] == "'" or data[:2] == "L'":
        pos, text = self.scan_until (source, "'")
        if pos == -1:
          token = 'ERROR'
        else:
          token = 'CHAR'

      # STRING/LSTRING
      elif data[0] == '"' or data[:2] == 'L"':
        pos, text = self.scan_until (source, '"')
        if pos == -1:
          token = 'ERROR'
        else:
          token = 'STRING'

      # IDENTIFIER
      elif data[0] in string.letters + '_':
        token = 'IDENTIFIER'
        pos, text = source.while_contains (string.letters + string.digits + '_')

      # NUMBER
      elif data[0] in string.digits	\
       or (data[0] == '.' and data[1] in string.digits):
        token = 'NUMBER'
        text  = self.scan_number (source)

      # PUNCTUATOR
      elif data[0] in '<>.-+=!&|*/%^#[]{}()?:;.;~<>':
        token = 'PUNCTUATOR'
        text  = self.scan_punct (source)

      # ERROR
      else:
        token = 'ERROR'
        text  = data[0]
        source.skip (1)

      # Headername FSM
      if state == 0 and text == '#':
        state = 1

      elif state == 1:
        if text == 'include':
          state = 2
        elif type not in ('SPACE', 'COMMENT'):
          state = 0
        
      elif state == 2:
        if type not in ('SPACE', 'COMMENT'):
          state = 0
        
      yield token, text, srow, scol, source.row, source.col


  #############################################################################
  # @brief scan until 'c' is found, checking escape sequences
  #############################################################################
  def scan_until (self, source, c):
    data   = source.peek ()
    length = len (data)
    pos    = 1
    escape = False

    while pos < length and (escape or data[pos] != c):

      if data[pos] == '\\':
        escape = not escape
      else:
        escape = False
      pos += 1

    source.skip (pos+1)

    if pos < length:
      return pos + 1, data[:pos+1]
    else:
      return -1, data

  #############################################################################
  # @brief scan NUMBER token
  #############################################################################
  def scan_number (self, source):
    data   = source.peek ()
    length = len (data)
    pos    = 1
    exp    = False
    chars  = string.ascii_letters + string.digits + '_.'

    while pos < length		\
      and data[pos] in chars	\
       or (exp and data[pos] in '+-'):	

      if data[pos] in 'EePp':
        exp = not exponent
      else:
        exp = False

      pos += 1

    source.skip (pos)
    return data[:pos]

  #############################################################################
  # @brief scan PUNCTUATOR
  #############################################################################
  def scan_punct (self, source):
    data = source.peek ()
    siz  = 0

    if data[:3] in ('<<=', '>>=', '...'):
      siz = 3

    elif data[:2] in ('->', '++', '--', '>>', '<<', '<=', '>=', '==', '!=',
                      '&&', '||', '*=', '/=', '%=', '+=', '-=', '&=', '^=',
                      '|=', '##'):
      siz = 2

    else:
      siz = 1

    source.skip (siz)
    return data[:siz]


if __name__ == '__main__':
  scanner = CppScanner (r"""// teste C++
// por Eduardo Aguiar

#include <iostream>

int
main ()
{
  char *str = "alo mundo";
  char c = 'A';
  int n = 95;

  for (int i = 0;i < 10;i++)
    std::cout << i << std::endl;
}""")

  for token, text, srow, scol, erow, ecol in scanner.scan ():
    print token, srow, scol, erow, ecol, text
