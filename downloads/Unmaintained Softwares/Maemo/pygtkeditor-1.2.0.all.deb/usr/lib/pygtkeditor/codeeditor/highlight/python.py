import gtk
import keyword
import codeeditor.tokenize as tokenize
import StringIO

###############################################################################
# @brief Highlight python code
###############################################################################
class PythonSyntax:
  language = 'python'
  description = 'Python'

  #############################################################################
  # @brief Populate buffer with tags
  #############################################################################
  def populate_buffer (self, buffer):
    buffer.create_tag ("python_keyword", foreground="#0000ff")
    buffer.create_tag ("python_string",  foreground="#004488")
    buffer.create_tag ("python_comment", foreground="#009900")

  #############################################################################
  # @brief Do highlight
  #############################################################################
  def scan (self, code):
    fp = StringIO.StringIO (code)

    try:
      for type, text, (srow, scol), (erow, ecol), line in	\
          tokenize.generate_tokens (fp.readline):
        tag = None

        if type == tokenize.NAME and keyword.iskeyword (text):
          tag = "python_keyword"

        elif type == tokenize.STRING:
          tag = "python_string"

        elif type == tokenize.COMMENT:
          tag = "python_comment"

        if tag:
          yield tag, (srow, scol), (erow, ecol)

    except tokenize.TokenError, e:
      pass
