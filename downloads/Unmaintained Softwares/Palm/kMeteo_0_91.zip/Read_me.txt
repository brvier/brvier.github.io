kMeteo v0.91

kMeteo was unmaintained since a long time. But due to a recent change in weather.com, kMeteo 0.9 didn't
work anymore.

I ve received many email from Palm Users, so i decided to try to fix it.
As i don't own any Palm, i've used the Garnet Emulator on Maemo.

So it should work.

Best regards,