====== Python For 4D ======


==== A 4D Plugin which add Python to 4D ====

Python For 4D is a 4D (4th Dimension) plugin which enable use of python inside 4D. It's require that Python 2.7 is installed on the host machine and support currently only Windows (Python 2.7 is available at http://python.org/download/).

The current version is an beta release version and is limited to 10 call at each launch of a database.

Python For 4D is actually only compatible with 4D V11 SQL, and 4D V12. If necessary, version for 4D 2003 and 4D 2004 can be produce on demand.

Python For 4D is actually in heavy development and API is subject to change in future.

==== API Documentation ====

  * PyExec (code; variable; result) -> ErrorCode
    * Exec a python multiline code and retrieve the content of a variable.
    * Parameters :
      * code (In/Text) : The python code to execute
      * variable (In/Text) : the name of the variable where to read the result in the global dict
      * result (Out/Text) : the content of 'variable' as a Text 
    * Return ErrorCode
      * 0 : No Error
      * 1 : Unregistered plugin
      * 2 : Invalid Parameters
      * 4 : Python Error

  * PyEval (statement; result) -> ErrorCode
    * Evaluate a python statement and return the result as text
    * Parameters :
      * statement (In/Text) : The python statement to evaluate
      * result (Out/Text) : the content of 'variable' as a Text 
    * Return ErrorCode
      * 0 : No Error
      * 1 : Unregistered plugin
      * 2 : Invalid Parameters
      * 4 : Python Error

  * PyRegister (licence) -> answer
    * Register the plugin to avoid the limitation of ten call. If registration is ok, answer will be equal to 1, else it ll be equal to 0.

==== Pricing ====
  * Development Licence : 99 Euros
  * Unlimited single user deployment Licence : 149 Euros 
  * Server deployment licence (per installation) : 59 Euros
  * Unlimited deployment and development licence : 349 Euros 
