<?
#kShareShop - Khertan Shareware Shop Maker
#(c)2007 by Beno�t HERVIER (khertan@khertan.net)
#This project's homepage is: http://khertan.net
#
#This program is free software; you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation; either version 2 of the License, or
#(at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#A commercial licence witch allow you to remove copyright message is available at 
#http://khertan.net
//Required $regname and $productname

include('variables.php');

$connect = mysql_connect($host,$username,$password);
if (!$connect) {
   die('Could not connect: ' . mysql_error());
}
@mysql_select_db($database) or die( "Unable to select database");

$transactionid = 0;
$price = 999;

$productname = $_POST['productname'];
$productname = htmlentities($productname);$productname = strip_tags($productname);
$regname = $_POST['regname'];
$regname = htmlentities($regname);$regname = strip_tags($regname);

include('template_top.php');

echo "<h3>Check out</h3>";
echo "<p>Product Name : $productname</p>";
echo "<p>Registration Name : $regname</p>";

$checkquery = "SELECT * FROM kstore_products WHERE productname = '$productname'";
$checkresult = mysql_query($checkquery);
$checkrow=mysql_fetch_assoc($checkresult);
$price = $checkrow["price"];
$productid = $checkrow["id"];

$command_date=time();

$checkquery = "INSERT INTO kstore_keys (command_date, regname, products_id) VALUES ('$command_date','$regname','$productid')";

$checkresult = mysql_query($checkquery);

$checkquery = "SELECT * FROM kstore_keys WHERE command_date ='$command_date' AND regname = '$regname'";
$checkresult = mysql_query($checkquery);
$checkrow=mysql_fetch_assoc($checkresult);
$transactionid = $checkrow["id"];

mysql_close($connect);

echo '<p><form action="'.$paypalurl.'" method="post">';echo '<input type="hidden" name="cmd" value="_xclick">';echo '<input type="hidden" name="business" value="google@khertan.net">';echo '<input type="hidden" name="item_name" value="'.$productname.'">';echo '<input type="hidden" name="item_number" value="'.$transactionid.'">';echo '<input type="hidden" name="amount" value="'.$price.'">';echo '<input type="hidden" name="no_shipping" value="1">';echo '<input type="hidden" name="return" value="http://khertan.net/kShareShop/thanks.html">';echo '<input type="hidden" name="no_note" value="1">';echo '<input type="hidden" name="currency_code" value="'.$device.'">';echo '<input type="hidden" name="lc" value="FR">';echo '<input type="hidden" name="bn" value="PP-BuyNowBF">';echo '<input type="image" src="'.$paypalBuyButton.'" border="0" name="submit" alt="Make payments with PayPal - it s fast, free and secure!">';echo '</form></p>';

?>

<?php include('template_bottom.php'); ?>