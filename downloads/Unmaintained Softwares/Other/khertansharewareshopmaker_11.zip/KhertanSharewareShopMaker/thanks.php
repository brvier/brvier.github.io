<?php 
#kShareShop - Khertan Shareware Shop Maker
#(c)2007 by Beno�t HERVIER (khertan@khertan.net)
#This project's homepage is: http://khertan.net
#
#This program is free software; you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation; either version 2 of the License, or
#(at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#A commercial licence witch allow you to remove copyright message is available at 
#http://khertan.net
include('variables.php'); ?>
<?php include('template_top.php'); ?>
   <p><?php echo $thanksMessage1;></p>
   <p><?php echo $thanksMessage2;></p>
   <p><?php echo $thanksMessage3;></p>
<?php include('template_bottom.php'); ?>