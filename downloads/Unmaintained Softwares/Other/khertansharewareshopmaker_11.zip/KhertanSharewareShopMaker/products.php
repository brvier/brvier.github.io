<?php 
#kShareShop - Khertan Shareware Shop Maker
#(c)2007 by Beno�t HERVIER (khertan@khertan.net)
#This project's homepage is: http://khertan.net
#
#This program is free software; you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation; either version 2 of the License, or
#(at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#A commercial licence witch allow you to remove copyright message is available at 
#http://khertan.net
include('variables.php'); ?>
<?php include('template_top.php'); ?>
  	<?php  
  	$connect = mysql_connect($host,$username,$password);
	if (!$connect) {
   		die('Could not connect: ' . mysql_error());
	}
	@mysql_select_db($database) or die( "Unable to select database");
           
	$checkquery = "SELECT * FROM kstore_products";
	$checkresult = mysql_query($checkquery);

	while ($checkrow=mysql_fetch_assoc($checkresult))
	{
		echo '<h2>'.$checkrow["productname"].'</h2>';
		echo '<p class="meta">Price : '.$checkrow["price"].' '.$device.'</p>';
		echo '<p class="meta">Description : '.$checkrow["description"].'</p>';
		echo '<p class="meta"><center><form action="checkout.php" method="post">'.$checkrow["regnametext"].'<br /><input type="text" name="regname" value="" /><input type="hidden" name="productname" value="'.$checkrow["productname"].'"/><br /><input type="image" src="'.$paypalBuyButton.'" border="0" name="submit" alt="Make payments with PayPal - it s fast, free and secure!"/></center></form></p>';
		echo '<p>&nbsp;</p>';
	}

	mysql_close($connect);

  	?>
<?php include('template_bottom.php'); ?>