<?php
#kShareShop - Khertan Shareware Shop Maker
#(c)2007 by Benoit HERVIER (khertan@khertan.net)
#This project's homepage is: http://khertan.net
#
#This program is free software; you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation; either version 2 of the License, or
#(at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#A commercial licence witch allow you to remove copyright message is available at 
#http://khertan.net

include('variables.php');

echo <<<END
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN"
  "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta name="generator" content=
  "HTML Tidy for Linux/x86 (vers 1 September 2005), see www.w3.org" />
  <meta http-equiv="Content-Type" content=
  "text/html; charset=us-ascii" />

  <title>
END;

echo $storeTitle;

echo <<<END
  <link href="style.css" rel="stylesheet" type="text/css" />
</head>

<body>
  <div id="container">
    <div id="header">
      <center><h1>
END;

echo "$storeTitle</h1></center><h2>$storeSlogan</h2>";

echo <<<END
<br />
      <hr />
    </div><!-- end header -->

    <div id="left">
      <h3><!-- Menu Title --></h3>

      <p><a href="http://www.khertan.net/home/">About</a><br />
		 <a href="products.php">Sharewares</a><br />
		 <a href="askresend.php">Retrieve registration code</a><br />
		 <a href="http://www.khertan.net/contact/">Contacts</a><br />
		 <a href="http://www.khertan.net/">Return to website</a>
      </p>

    </div><!-- end left division -->

    <div id="main">
END;

?>