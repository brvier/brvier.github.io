<?php
#kShareShop - Khertan Shareware Shop Maker
#(c)2007 by Beno�t HERVIER (khertan@khertan.net)
#This project's homepage is: http://khertan.net
#
#This program is free software; you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation; either version 2 of the License, or
#(at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#A commercial licence witch allow you to remove copyright message is available at 
#http://khertan.net

/*set the following variables*/

/* General Conf */
$storeTitle="Khertan.net's Store";
$storeDescription="Khertan.net's Store";
$storeKeywords="shareware, shop, store, klauncher";
$storeSlogan="The Khertan.net Store :: Fast and Easy";

/*Database info*/
$username="username";
$password="password";
$database="databasename";
$host="hostname";

/*path to send_url.php*/
$storename = "Khertan.net Store";
$scriptpath = "http://khertan.net/store/";
$email = "khertan@khertan.net";
$paypalemail = "google@khertan.net";

/* Device */ 
/* The device as paypal understand it. In letter (USD for US Dollar for example) */
$device = "EUR";

/* Message */
$resendSubjectMessage = "Registrations keys from Khertan.net";
$resendHeaderMessage = "Thanks for supporting shareware. Here your registered products :";
$resendFooterMessage = "";
$resendpagemessage = "Your registrations keys have been sent to your email.";

$sendSubjectMessage = "Registration key order from Khertan.net";
$sendHeaderMessage = "Thanks for supporting shareware !";
$sendFooterMessage = "If you cannot register your shareware, please contact us at " . $email . ".";

$thanksMessage1 = "Thanks for supporting shareware.";
$thanksMessage2 = "You ll receive your licence key in the next 48 hours by mail at your paypal email address. It's an automatic process so if you don't receive it contact us by the contact form.";
$thanksMessage3 = "If you lost your registrations keys you can also ask that their are resend by mail with this <a href=\"askresend.php_check_syntax\">form.</a>";

$homeMessage = "Welcome to Khertan.net Store. Here you can bought my shareware 24h/24h and 7d/7d and you ll get your registration code mainly instantly, or maybe in less than 48 hours. It s depends on paypal.";

/* Buy Button */
$paypalBuyButton = "https://www.sandbox.paypal.com/en_US/i/btn/x-click-but5.gif";
//Uncomment to leave test mode (sandbox) : 
//$paypalBuyButton = "https://www.paypal.com/en_EN/i/btn/x-click-but5.gif";

/* Registration id for generating serial test */
// Now it s specific for each product, so it s stocked in the database
//$regnametext="Enter your Hotsync name : ";

/* Paypal URL (to switch to production) */
$paypalurl = "https://www.sandbox.paypal.com/cgi-bin/webscr";
//Uncomment to leave test mode (sandbox) : 
//$paypalurl = "https://www.paypal.com/cgi-bin/webscr";
?>
