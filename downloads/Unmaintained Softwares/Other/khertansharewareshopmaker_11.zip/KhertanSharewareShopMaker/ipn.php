<?php
#kShareShop - Khertan Shareware Shop Maker
#(c)2007 by Beno�t HERVIER (khertan@khertan.net)
#This project's homepage is: http://khertan.net
#
#This program is free software; you can redistribute it and/or modify
#it under the terms of the GNU General Public License as published by
#the Free Software Foundation; either version 2 of the License, or
#(at your option) any later version.
#
#This program is distributed in the hope that it will be useful,
#but WITHOUT ANY WARRANTY; without even the implied warranty of
#MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#GNU General Public License for more details.
#You should have received a copy of the GNU General Public License
#along with this program; if not, write to the Free Software
#Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
#
#A commercial licence witch allow you to remove copyright message is available at 
#http://khertan.net
include('variables.php');

$connect = mysql_connect($host,$username,$password);
if (!$connect) {
   die('Could not connect: ' . mysql_error());
}
@mysql_select_db($database) or die( "Unable to select database");

$req = 'cmd=_notify-validate';
	foreach ($_POST as $key => $value)
	{
		$value = urlencode(stripslashes($value));
		$req .= "&$key=$value";
	}

$header .= "POST /cgi-bin/webscr HTTP/1.0\r\n";
$header .= "Content-Type: application/x-www-form-urlencoded\r\n";
$header .= "Content-Length: " . strlen($req) . "\r\n\r\n";

 $ch = curl_init();
curl_setopt($ch, CURLOPT_URL,"http://www.sandbox.paypal.com/cgi-bin/webscr");
curl_setopt($ch, CURLOPT_FAILONERROR, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $req);
$paypal_response = curl_exec($ch);
curl_close ($ch);

//get variables
$receiver_email = $_POST['receiver_email'];
$payer_email = $_POST['payer_email'];
$item_name = $_POST['item_name'];
$item_number = $_POST['item_number'];
$amount = $_POST['mc_gross'];
$payment_status = $_POST['payment_status'];
$txn_type = $_POST['txn_type'];
$payer_address_country = $_POST['address_country'];
$payer_first_name= $_POST['first_name'];
$payer_last_name= $_POST['last_name'];

$message = $payer_email . "\n";
$message .= $item_name . "\n";
$message .= $item_number . "\n";
$message .= $amount . "\n";
$message .= $txn_type . "\n";
$message .= $payment_status;

if (ereg('VERIFIED',$paypal_response)) {
$response_verified = 1;
$ipn_result = 'VERIFIED';
if ($payment_status == "Completed")
{

//Verification du prix
$checkquery = "SELECT * FROM kstore_keys, kstore_products WHERE kstore_keys.id =$item_number AND kstore_products.id = kstore_keys.products_id";
$checkresult = mysql_query($checkquery);
$checkrow=mysql_fetch_assoc($checkresult);
$price = $checkrow["price"];
$productname = $checkrow["productname"];
$regname = $checkrow["regname"];
$regeval = $checkrow["keygenerator"];

if (($price == $amount) && ($receiver_email == $paypalemail))
{
	
//G�n�ration du numero de s�rie
eval($regeval);

// Enregistrement du timestamp
$paiementdate = time();

$query = "UPDATE kstore_keys SET paiements_date='".$paiementdate."' WHERE id =".$item_number."";
mysql_query($query);
//mysql_close($connect);

$query = "UPDATE kstore_keys SET regcode='".$regkey."' WHERE id =".$item_number."";
mysql_query($query);
//mysql_close($connect);


$query = "UPDATE kstore_keys SET payer_email='".$payer_email."' WHERE id =".$item_number."";
mysql_query($query);
//mysql_close($connect);

$query = "UPDATE kstore_keys SET payer_address_country='".$payer_address_country."' WHERE id =".$item_number."";
mysql_query($query);
//mysql_close($connect);

$query = "UPDATE kstore_keys SET payer_first_name='".$payer_first_name."' WHERE id =".$item_number."";
mysql_query($query);
//mysql_close($connect);

$query = "UPDATE kstore_keys SET payer_last_name='".$payer_last_name."' WHERE id =".$item_number."";
mysql_query($query);
mysql_close($connect);

//Envoie du mail au client
$to = $payer_email;
$subject = $sendSubjectMessage;
$body = $sendHeaderMessage. "\n\n" . "Registration details for " . $productname . ": \n" . "Registration Name : " . $regname . "\nRegistration Key : " . $regkey . "\n\n" . $sendFooterMessage;

mail($to, $subject, $body,
    "To: " . $to . "\n" .
    "From: ". $email ."\n" .
    "X-Mailer: PHP 4.x");

//Envoi du mail au vendeur
mail($email, "Order Received", $message, "From: ". $email);


}
else
{
mail($email, "Order Payment Amount Invalid", $message, "From: ". $email);

}
}

} else if (ereg('INVALID',$paypal_response)) {
$response_invalid = 1;
$ipn_result = 'INVALID';


mail($email, "Order Received - Invalid IPN", $message, "From: ". $email);

$to = $payer_email;
$subject = $storename . " Order";
$body = "Your download was not completed, please contact us at " . $email . ".";

mail($to, $subject, $body,
    "To: " . $to . "\n" .
    "From: " . $email . "\n" .
    "X-Mailer: PHP 4.x");


} else {
echo 'Error: no valid $paypal_response received.';


mail($email, "Order Received - No IPN Response", $message, "From: " . $email);

$to = $payer_email;
$subject = $storename . " Order";
$body = "Your download was not completed, please contact us at " . $email . ".";

mail($to, $subject, $body,
    "To: " . $to . "\n" .
    "From: " . $email . "\n" .
    "X-Mailer: PHP 4.x");
}

?>