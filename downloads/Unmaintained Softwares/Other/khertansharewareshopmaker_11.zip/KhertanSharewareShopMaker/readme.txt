First Things FirstWelcome. Khertan Shareware Shop Maker is an php application witch allow you to sell registrations keys for your sharewares automatically with Paypal.

Installation: Famous 6-step install

1) Create an paypal account, upgrade it to premium account. Your account must be a verified account (follow the paypal procedure). Then in the preferences 'Instant Payments Notification', modify it to true and enter the path of the file 'ipn.php' (for example 'http://www.mydomain.com/myshop/ipn.php'). And always in the preferences activate the automatic return and enter the path to the file 'thanks.php' (for example 'http://www.mydomain.com/myshop/thanks.php').
2) Unzip the package in an empty directory.3) Open up variables.php with a text editor like WordPad or similar and fill in your database connection details, and other customization variables.
4) Create the tables in your database with the create commands of the sql.txt file.
5) Upload everything except the sql.txt file to your domain.
6) Now enter new product in your database to begin to sell it.

To enter product you must do it manually. There are not yet interface to do it. So here some explanation.

Explain on the kstore_products table.
This table contain your products.
id : is a reference witch is automatically generated.
productname : is the name of your shareware.
price : is the price of your shareware.
description : is the description of your soft.
regnametext : is the string displayed in the product list about the identification shareware scheme. (MAC Address, palm hotsync name, domain name ...)
keygenerator : is the code that generate the key for your client. Here an example of a code generator based on the name given by the user when he bought your shareware.

$regkey=0;  for ($i=0; $i < strlen($regname); $i++) {  	$regkey = $regkey + (ord(($regname[$i])))+3; }
 
Here the key is an addition of all the ascii characters of the name + 3.
The two variables are $regkey, the key generated and $regname the name entered by the user. 

You can also customize the two template file ('template_top.php','template_bottom.php') and the file variables.php to customize it. But you can't remove the copyright until you buy an commercial licence.


System Recommendations    * PHP version 4.1 or higher.    * MySQL version 4.0 or higher.
