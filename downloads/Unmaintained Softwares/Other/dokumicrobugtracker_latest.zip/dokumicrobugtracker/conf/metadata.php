<?php
/**
 * Metadata for configuration manager plugin
 * Additions for the discussion plugin
 *
 * @author    Esther Brunner <wikidesign@gmail.com>
 */

$meta['send_email']    = array('onoff');
$meta['use_captcha']    = array('onoff');
$meta['email_address']  =  array('string');
$meta['severities']  =  array('string');
$meta['email_subject_template'] =  array('string');
$meta['email_body_template'] =  array('string');
$meta['statuses']  =  array('string');
//Setup VIM: ex: et ts=2 enc=utf-8 :
